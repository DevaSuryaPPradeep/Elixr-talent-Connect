package com.elixr.job.rest.data.response;

import com.elixr.job.rest.data.dto.Job;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class JobListResponse {

    private List<Job> jobs;
}
