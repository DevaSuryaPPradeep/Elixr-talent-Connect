package com.elixr.job.rest.controller;

import com.elixr.job.rest.data.dto.Job;
import com.elixr.job.rest.data.response.JobListResponse;
import com.elixr.job.service.JobListService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/jobs")
public class JobListController {

    private final JobListService jobListService;

    public JobListController(JobListService jobListService) {
        this.jobListService = jobListService;
    }


    @GetMapping
    private JobListResponse getAllJobs() {
        List<Job> jobs = jobListService.getAllJobs();
        return JobListResponse.builder().jobs(jobs).build();
    }
}
