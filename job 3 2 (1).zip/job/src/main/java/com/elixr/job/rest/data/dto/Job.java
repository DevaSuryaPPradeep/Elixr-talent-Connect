package com.elixr.job.rest.data.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Job {

    private  String id;
    private String title;
    private String department;
    private String postedDate;
    private String deadlineDate;
    private String description;
    private String responsibilities;
    private String requirements;
    private String location;
    private String salary;
    private String status;
}
